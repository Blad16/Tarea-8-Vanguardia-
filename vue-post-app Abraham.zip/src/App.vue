<template>
  <div id="app">
    <Formulario />
  </div>
</template>

<script>
import Formulario from './components/Formulario.vue'

export default {
  components: {
    Formulario
  }
}
</script>