<template>
  <div class="container">
    <h2>Registrar Nuevo Dato</h2>
    <form @submit.prevent="enviarFormulario">
      <div>
        <label>Nombre:</label>
        <input v-model="formulario.nombre" required />
      </div>
      <div>
        <label>Correo:</label>
        <input v-model="formulario.correo" type="email" required />
      </div>
      <button type="submit">Enviar</button>
      <p v-if="mensaje">{{ mensaje }}</p>
    </form>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      formulario: {
        nombre: '',
        correo: ''
      },
      mensaje: ''
    }
  },
  methods: {
    async enviarFormulario() {
      try {
        const response = await axios.post('http://localhost:3000/api/usuarios', this.formulario)
        this.mensaje = 'Registro exitoso'
        console.log('Respuesta:', response.data)
      } catch (error) {
        this.mensaje = 'Error al registrar'
        console.error(error)
      }
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 400px;
  margin: auto;
  padding: 1rem;
}
input {
  width: 100%;
  padding: 0.5rem;
  margin-bottom: 1rem;
}
button {
  padding: 0.5rem 1rem;
}
</style>